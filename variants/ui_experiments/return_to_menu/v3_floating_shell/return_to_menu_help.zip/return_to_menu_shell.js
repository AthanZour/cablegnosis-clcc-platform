(() => {
  const AUTO_HIDE_MS = 2200;

  // Guard: μην διπλοδημιουργηθεί
  if (document.querySelector(".return-to-menu-ribbon")) return;

  let state = "HIDDEN";
  let lastScrollY = window.scrollY;
  let timer = null;

  const ribbon = document.createElement("div");
  ribbon.className = "return-to-menu-ribbon";
  ribbon.innerHTML = `
    <img
      class="return-to-menu-shape"
      src="/assets/return_to_menu.svg"
      alt=""
    />
    <div class="return-to-menu-overlay">
      <span class="label">RETURN TO MENU</span>
      <img
        class="return-icon"
        src="/assets/return_to_menu_help.png"
        alt=""
      />
    </div>
  `;
  document.body.appendChild(ribbon);

  function show() {
    if (state !== "HIDDEN") return;
    state = "VISIBLE";
    ribbon.classList.add("visible");
    clearTimeout(timer);
    timer = setTimeout(hide, AUTO_HIDE_MS);
  }

  function hide() {
    if (state !== "VISIBLE") return;
    state = "HIDDEN";
    ribbon.classList.remove("visible");
    clearTimeout(timer);
  }

  window.addEventListener(
    "scroll",
    () => {
      const y = window.scrollY;
      if (y < lastScrollY && state === "HIDDEN") show();
      if (y > lastScrollY && state === "VISIBLE") hide();
      lastScrollY = y;
    },
    { passive: true }
  );

  document.addEventListener("click", (e) => {
    if (state === "VISIBLE" && !ribbon.contains(e.target)) hide();
  });

  ribbon.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    window.scrollTo({ top: 0, behavior: "smooth" });
    hide(); // απλό hide, ΟΧΙ destroy
  });
})();