(() => {
  // ============================================================
  // Return To Menu – v2 Drop-Down Ribbon (Final)
  // ============================================================

  const AUTO_HIDE_MS = 3500; // ⬅️ 3.5 seconds

  let state = "HIDDEN";
  let lastScrollY = window.scrollY;
  let autoHideTimer = null;

  const ribbon = document.createElement("div");
  ribbon.className = "return-to-menu-ribbon";
  ribbon.innerHTML = `
    <div class="return-to-menu-ribbon-inner">
      <img src="/assets/return_to_menu.svg" />
      <span>Return to menu</span>
    </div>
  `;
  document.body.appendChild(ribbon);

  function clearAutoHide() {
    if (autoHideTimer) clearTimeout(autoHideTimer);
    autoHideTimer = null;
  }

  function startAutoHide() {
    clearAutoHide();
    autoHideTimer = setTimeout(hide, AUTO_HIDE_MS);
  }

  function show() {
    if (state !== "HIDDEN") return;
    state = "VISIBLE";
    ribbon.classList.add("visible");
    startAutoHide();
  }

  function hide() {
    if (state !== "VISIBLE") return;
    state = "HIDDEN";
    ribbon.classList.remove("visible");
  }

  window.addEventListener(
    "scroll",
    () => {
      const y = window.scrollY;
      const delta = y - lastScrollY;

      if (delta < 0 && state === "HIDDEN") show();
      if (delta > 0 && state === "VISIBLE") hide();

      lastScrollY = y;
    },
    { passive: true }
  );

  document.addEventListener("click", (e) => {
    if (state === "VISIBLE" && !ribbon.contains(e.target)) hide();
  });

  ribbon.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    window.scrollTo({ top: 0, behavior: "smooth" });
    hide();
  });
})();