(() => {
  // ============================================================
  // Return To Menu – Progressive Shell
  // Pure JS | No Dash | No app.py changes
  // ============================================================

  const AUTO_HIDE_MS = 7000;
  const FADE_MS = 500;

  let state = "HIDDEN"; // HIDDEN | VISIBLE | FADING_OUT
  let lastScrollY = window.scrollY;
  let autoHideTimer = null;

  // ------------------------------------------------------------
  // Create shell DOM
  // ------------------------------------------------------------
  const shell = document.createElement("div");
  shell.className = "return-to-menu-shell";
  shell.innerHTML = `
    <div class="return-shell-inner">
      <img src="/assets/return_to_menu.svg" alt="Return to menu" />
      <span>Return to menu</span>
    </div>
  `;
  document.body.appendChild(shell);

  // ------------------------------------------------------------
  // Helpers
  // ------------------------------------------------------------
  function clearAutoHide() {
    if (autoHideTimer) {
      clearTimeout(autoHideTimer);
      autoHideTimer = null;
    }
  }

  function startAutoHide() {
    clearAutoHide();
    autoHideTimer = setTimeout(() => {
      if (state === "VISIBLE") fadeOut();
    }, AUTO_HIDE_MS);
  }

  function show() {
    if (state !== "HIDDEN") return;
    state = "VISIBLE";
    shell.classList.add("visible");
    startAutoHide();
  }

  function fadeOut() {
    if (state !== "VISIBLE") return;
    state = "FADING_OUT";
    shell.classList.remove("visible");
    shell.classList.add("fading-out");

    clearAutoHide();

    setTimeout(() => {
      shell.classList.remove("fading-out");
      state = "HIDDEN";
    }, FADE_MS);
  }

  // ------------------------------------------------------------
  // Scroll detection
  // ------------------------------------------------------------
  window.addEventListener(
    "scroll",
    () => {
      const currentY = window.scrollY;
      const delta = currentY - lastScrollY;

      // Scroll UP
      if (delta < 0) {
        if (state === "HIDDEN") show();
        if (state === "VISIBLE") startAutoHide();
      }

      // Scroll DOWN
      if (delta > 0) {
        if (state === "VISIBLE") fadeOut();
      }

      lastScrollY = currentY;
    },
    { passive: true }
  );

  // ------------------------------------------------------------
  // Click outside shell
  // ------------------------------------------------------------
  document.addEventListener("click", (e) => {
    if (state !== "VISIBLE") return;
    if (!shell.contains(e.target)) {
      fadeOut();
    }
  });

  // ------------------------------------------------------------
  // Click on shell
  // ------------------------------------------------------------
  shell.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });

    fadeOut();
  });
})();